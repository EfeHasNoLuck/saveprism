invented container fixture
